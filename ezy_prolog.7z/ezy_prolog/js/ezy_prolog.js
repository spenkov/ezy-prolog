// EZY PROLOG JAVASCRIPT SUPPORT (c) 2020 Sergei Penkov

	var ezy_prolog	= '/../cgi-bin/ezy_prolog_cgi.exe';
	var empty	= "<div style='height:50px'>...</div>";
	function ezy_help(id,id_target,group){
		var search_for	= document.getElementById(id).value;
		$.post(ezy_prolog,{
					COMMAND:'search_help',SEARCH:search_for,GROUP:group},
			function(data,status){
				$('#'+id_target).html(data);
				refresh_bootstrap(id_target);
			});
	};
	function ezy_submit(id_form,id_target,programm,callback_predicate,api) {
		// form attributes:  get target id and API string
		// Get all the forms elements and their values
		var values = $('form').serialize();
			$.post(ezy_prolog,{
					API:api,COMMAND:'form_callback',SOURCE:programm,
					CALLBACK:callback_predicate+'&'+values},function(data,status){
				$('#'+id_target).html(data);
				refresh_bootstrap(id_target);
			});
	};

	function refresh_bootstrap(id_target) {
			refresh_tooltips();
			refresh_datatables(id_target);
			refresh_sparklines();
	};
	function refresh_tooltips() {
		$('[data-toggle="tooltip"], .tooltip').tooltip("hide");
		$('[data-toggle="tooltip"]').tooltip({trigger : 'hover'});
		$("[data-toggle='popover']").popover();
	};
	function refresh_sparklines() {
	/*
			$.sparkline_display_visible();
	*/
			$('.sparkline[data-type="pie"]').each(function(){
				var height  = $(this).attr('data-height');
				var values  = $(this).attr('data-values');
				var colors  = $(this).attr('data-slice-colors');
				var spark_line_values = JSON.parse('['+values+']');
				var str	= colors.replace(/"/g, "'");
				var spark_line_colors = JSON.parse('['+colors+']');
				var color1 = spark_line_colors[0];
	//			console.log('Refresh sparklinke height = '+height+', values = '+spark_line_values+', colors = '+spark_line_colors);
				$(this).sparkline(spark_line_values, {
						type:'pie', 
						height: height+'px', 
						sliceColors: color1})
			})
	}
	function ezy_editor_select(id_editor,position_start,position_end) {
			console.log('Select id='+id_editor+', Start '+position_start+' to '+position_end);
			editAreaLoader.setSelectionRange(id_editor,position_start,position_end);
	}
	
	function ezy_compile(id_from,id_target,api_string) {
		console.log('ezy_compile. Target = ' +id_target );
//			var source = document.getElementById(id_from).value;
		var source = editAreaLoader.getValue(id_from);

		$('#'+id_target).html(empty);
		$('#'+id_target).addClass('whirl traditional');
		$.post(ezy_prolog,{COMMAND:api_string,SOURCE:source},function(data,status){
			$('#'+id_target).html(data);
			$('#'+id_target).removeClass('whirl traditional');
			});
	}
	function ezy_execute(id_goal,id_from,id_target,id_tab,api_string) {
		show_tab(id_tab),
		console.log('ezy_execute. Target = ' +id_target );
		var source = editAreaLoader.getValue(id_from);
		var goal = document.getElementById(id_goal).value;
		$('#'+id_target).html(empty);
		$('#'+id_target).addClass('whirl traditional');
		$.post(ezy_prolog,{
				width:document.body.clientWidth,height:document.body.clientHeight,
				COMMAND:api_string,
				GOAL:goal,SOURCE:source
			},function(data,status){
			$('#'+id_target).html(data);
			$('#'+id_target).removeClass('whirl traditional');
			});
	}
	function ezy_edit_source(id_target,id_program_source,api_string) {
		console.log('ezy_edit_source. ID = ' +id_program_source );
		$('#'+id_target).html(empty);
		$('#'+id_target).addClass('whirl traditional');
		$.post(ezy_prolog,{
				width:document.body.clientWidth,height:document.body.clientHeight,
				COMMAND:api_string
				},function(data,status){
			$('#'+id_target).html(data);
			$('#'+id_target).removeClass('whirl traditional');
			refresh_bootstrap('#'+id_target);
			editAreaLoader.init({
				id : id_program_source,		// textarea id
				syntax: "cpp",				// syntax to be uses for highgliting
				start_highlight: true,		// to display with highlight mode on start-up
				font_size:	12,
				toolbar: "search,go_to_line,undo,redo,word_wrap,fullscreen"
			});
		});
	}
	function show_tab(id_tab) {
		$('a[href="#' + id_tab + '"]').trigger('click');
	}
	function ezy_run_selected(id_target,id_row,id_tab_active,api_string) {
		show_tab(id_tab_active),
		$("tr[role|='row']").removeClass('info');
		$('#'+id_target).html(empty);
		$('#'+id_target).addClass('whirl traditional');
		$.post(ezy_prolog,{
				width:document.body.clientWidth,height:document.body.clientHeight,
				COMMAND:api_string
				},function(data,status){
			$('#'+id_target).html(data);
			$('#'+id_target).removeClass('whirl traditional');
			refresh_bootstrap('#'+id_target);
			$('#'+id_row).addClass('info');
		});
	}
	function ezy_run(id_target,id_tab,api_string) {
		show_tab(id_tab),
		console.log('ezy_post. Target = ' +id_target );
		$('#'+id_target).html(empty);
		$('#'+id_target).addClass('whirl traditional');
		$.post(ezy_prolog,{
				width:document.body.clientWidth,height:document.body.clientHeight,
				COMMAND:api_string
				},function(data,status){
			$('#'+id_target).html(data);
			$('#'+id_target).removeClass('whirl traditional');
			refresh_datatables('#'+id_target);
			});
	}	
	function ezy_post(id_target,api_string) {
		show_tab('id_list_result'),
		$('#'+id_target).html(empty);
		$('#'+id_target).addClass('whirl traditional');
		$.post(ezy_prolog,{
				width:document.body.clientWidth,height:document.body.clientHeight,
				COMMAND:api_string
				},function(data,status){
			$('#'+id_target).html(data);
			$('#'+id_target).removeClass('whirl traditional');
			refresh_bootstrap('#'+id_target);
			});
	}
	function refresh_datatables(id_target) {
		console.log('refresh_datatables started');
			$(id_target+' .datatable').each(function(){
					var id = $(this).attr('id');
					var options = $(this).attr('options');
					var str	= options.replace(/'/g, '"');
					try { 
						var parameters = JSON.parse(str);
					} catch (err) {
						try { 
							$('#'+id).DataTable();
							console.log('refresh_datatables fail JSON id_target='+id_target+', Parse str =['+str+']');
						} catch (err) {
							console.log('refresh_datatables error failed to initialize id =['+id+']');
						}
					}
					try { 
						try { 
						$('#'+id).DataTable(parameters);
							console.log('refresh_datatables init successfull id =['+id+']');
						} catch (err) {
							console.log('refresh_datatables failed to initialize id =['+id+'], parameters='+JSON.stringify(parameters));
						}
					} catch (err) {
						console.log('refresh_datatables error. ID '+id+', options = '+str);
					}
			})
		};
		function expand() {
			try { 
				document.getElementById("id_left_sidebar").style.width = (document.body.clientWidth - 10) /4 + 'px';
				document.getElementById("id_left_sidebar").className = "visible col-xs-12 col-sm-3 col-md-3 col-lg-3";
				document.getElementById("id_right_sidebar").style.width = (document.body.clientWidth /4 - 5) + 'px';
				document.body.sidebar		= 'hide';
				} catch (err1) {
						console.log('openNav - no side bar');
			};
		} 
		/* Set the width of the sidebar to 0 and the left margin of the page content to 0  */
		function collapse() {
			try { 
			  document.getElementById("id_left_sidebar").style.width = "0";
			  document.getElementById("id_left_sidebar").className = "hidden";
			  document.getElementById("id_right_sidebar").style.width = (document.body.clientWidth /2 - 5) + 'px';
			  document.body.sidebar		= 'show';
				} catch (err1) {
						console.log('closeNav - no side bar');
			};

		}

function ezy_save_editable(id_source,id_target,api_string) {
	console.log("ezy_save_editable started");
	$('#'+id_target).addClass('whirl traditional');
	var source 	= document.getElementById(id_source).innerHTML;	
	var no_html = source.replace(/(\r\n|\n|\r|\t)/g, ''); //remove tabs, nl
//	source = source.replace(/<div[^>]*?>[\s\S]*?<\/div>/gi, ''); //remove divs
	var source_enc = encodeURI(no_html);
	var source_1 = replaceHtmlEntites(source_enc);
	var source_2 = source_1.replace("&", "*#*"); // replace in changemate back to &
	try { 
		$.post(ezy_prolog,{
			width:document.body.clientWidth,height:document.body.clientHeight,
			COMMAND:api_string,
			DATA:source_2
		},function(data,status){
			$('#'+id_target).html(data);
			$('#'+id_target).removeClass('whirl traditional');
			refresh_datatables('#'+id_target);
			refresh_sparklines();
		});
	} catch (err) {	
			$('#'+id_target).removeClass('whirl traditional');
			$('#'+id_target).html('<span class="fa fa-warning text text-danger"></span>');
	}
}
function ezy_save_editable_text(id_source,id_target,api_string) {
	$('#'+id_target).addClass('whirl traditional');
	var source 	= document.getElementById(id_source).textContent ;	
	var source_2 = source.replace("&", "*#*"); // replace in changemate back to &
	source_2 = source_2.replace(/(\r\n|\n|\r|\t)/g, ''); //remove tabs, nl
	try { 
		$.post(ezy_prolog,{
			width:document.body.clientWidth,height:document.body.clientHeight,
			COMMAND:api_string,
			DATA:source_2
		},function(data,status){
			$('#'+id_target).html(data);
			$('#'+id_target).removeClass('whirl traditional');
		});
	} catch (err) {	
			$('#'+id_target).removeClass('whirl traditional');
			$('#'+id_target).html('<span class="fa fa-warning text text-danger"></span>');
	}
}
function replaceHtmlEntites(string) {
    var div = document.createElement("div");
    div.innerHTML = string;
    return div.textContent || div.innerText;
}
 


